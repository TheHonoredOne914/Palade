import type { AgentFinding, Severity } from '../agents/base.js'
import type { CrossAgentFinding } from '../orchestrator/types.js'
import type {
  ScoreCategory,
  CategoryScore,
  ScoreBreakdown,
  ScoreResult
} from './types.js'

const CATEGORY_AGENT_MAP: Record<ScoreCategory, string> = {
  security: 'security',
  architecture: 'architecture',
  performance: 'performance',
  maintainability: 'maintainability',
  deadCode: 'deadCode',
  testIntelligence: 'testIntelligence'
}

const SEVERITY_WEIGHTS: Record<Severity, number> = {
  critical: 10,
  high: 5,
  medium: 2,
  low: 0.5,
  info: 0
}

export function countBySeverity(
  findings: AgentFinding[],
  agentName: string
): { total: number; critical: number; high: number } {
  let total = 0
  let critical = 0
  let high = 0

  for (const f of findings) {
    if (f.agentName === agentName) {
      total++
      if (f.severity === 'critical') critical++
      if (f.severity === 'high') high++
    }
  }

  return { total, critical, high }
}

export function calculateCategoryScore(
  findings: AgentFinding[],
  category: ScoreCategory
): CategoryScore {
  const agentName = CATEGORY_AGENT_MAP[category]
  const { total, critical, high } = countBySeverity(findings, agentName)

  let penalty = 0
  for (const f of findings) {
    if (f.agentName === agentName) {
      penalty += SEVERITY_WEIGHTS[f.severity]
    }
  }

  // Cap category penalty at 90 so a single category can't zero out the score
  const cappedPenalty = Math.min(penalty, 90)
  const score = Math.max(10, Math.round(100 - cappedPenalty))

  return {
    category,
    score,
    findingCount: total,
    criticalCount: critical,
    highCount: high
  }
}

export function calculateTotalPenalty(findings: AgentFinding[]): number {
  let penalty = 0
  for (const f of findings) {
    penalty += SEVERITY_WEIGHTS[f.severity]
  }
  return penalty
}

export function calculateCrossAgentPenalty(
  crossFindings: CrossAgentFinding[]
): number {
  let penalty = 0
  for (const cf of crossFindings) {
    if (cf.severity === 'critical') penalty += 15
    else if (cf.severity === 'high') penalty += 8
    else if (cf.severity === 'medium') penalty += 4
  }
  return penalty
}

export function calculateScore(
  findings: AgentFinding[],
  crossAgentFindings: CrossAgentFinding[],
  previousScore: number | null = null
): ScoreResult {
  const categories: ScoreCategory[] = [
    'security',
    'architecture',
    'performance',
    'maintainability',
    'deadCode',
    'testIntelligence'
  ]

  const categoryScores = categories.map((cat) =>
    calculateCategoryScore(findings, cat)
  )

  const findingPenalty = calculateTotalPenalty(findings)
  const crossAgentPenalty = calculateCrossAgentPenalty(crossAgentFindings)
  const totalPenalty = findingPenalty + crossAgentPenalty
  // Average category scores for a balanced overall score
  const avgCategoryScore = categoryScores.reduce((sum, c) => sum + c.score, 0) / categoryScores.length
  // Blend: 60% average category score, 40% penalty-based score
  const penaltyScore = Math.max(5, Math.round(100 - Math.min(totalPenalty, 95)))
  const total = Math.round(avgCategoryScore * 0.6 + penaltyScore * 0.4)

  const breakdown: ScoreBreakdown = {
    total,
    categories: categoryScores,
    findingCount: findings.length,
    crossAgentCount: crossAgentFindings.length
  }

  const delta = previousScore !== null ? total - previousScore : 0

  return {
    score: total,
    breakdown,
    previousScore,
    delta
  }
}
