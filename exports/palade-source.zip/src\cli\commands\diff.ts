import { loadConfig } from '../../config/loader.js'
import { initRouter } from '../../providers/router.js'
import { walkProject, detectLanguages } from '../../ingestion/walker.js'
import { chunkFiles } from '../../ingestion/chunker.js'
import { estimateTotalTokens } from '../../orchestrator/scheduler.js'
import { runSwarm } from '../../orchestrator/swarm.js'
import { calculateScore } from '../../scorer/calculator.js'
import { readHistory, appendEntry } from '../../scorer/history.js'
import { reportJson } from '../../reporters/json.js'
import { writeHtmlReport, startLocalServer } from '../../reporters/html.js'
import { reportMarkdown } from '../../reporters/markdown.js'
import { isGitRepo, getCurrentBranch, getChangedFiles, getBaseScore } from '../../diff/git.js'
import { compareFindings, rankIntroducedFindings } from '../../diff/comparator.js'
import { printDiffBanner, printDiffSummary } from '../../reporters/terminal.js'
import { theme } from '../../ui/theme.js'
import type { ScopeOptions } from '../../ingestion/types.js'
import type { AgentContext, AgentName, DiffContext } from '../../agents/base.js'
import chalk from 'chalk'
import ora from 'ora'
import { mkdirSync, existsSync } from 'node:fs'
import { join, basename } from 'node:path'

interface DiffOpts {
  base?: string
  ci?: boolean
}

export async function diffCommand(opts: DiffOpts): Promise<void> {
  const projectRoot = process.cwd()
  const base = opts.base ?? 'main'

  try {
    if (!(await isGitRepo(projectRoot))) {
      console.error(theme.error('  Not a git repository. palade diff requires git.'))
      process.exit(1)
    }

    const config = await loadConfig()
    await initRouter(config)

    const headBranch = await getCurrentBranch(projectRoot)
    console.log(theme.dim(`  Comparing ${headBranch} → ${base}...`))

    const changedFiles = await getChangedFiles(base, projectRoot)

    if (changedFiles.length === 0) {
      console.log(theme.success(`  ✓ No changed files vs ${base}`))
      process.exit(0)
    }

    const additions = changedFiles.reduce((s, f) => s + f.additions, 0)
    const deletions = changedFiles.reduce((s, f) => s + f.deletions, 0)
    console.log(
      theme.dim(
        `  ${changedFiles.length} changed files (+${additions} / -${deletions})`
      )
    )

    const nonDeleted = changedFiles.filter((f) => f.status !== 'deleted')
    const scope: ScopeOptions = {
      projectRoot,
      files: nonDeleted.map((f) => f.path),
    }

    const manifests = await walkProject(projectRoot, scope)
    const chunks = await chunkFiles(manifests)

    console.log(
      theme.dim(
        `  Chunking: ${manifests.length} files → ${chunks.length} chunks (~${estimateTotalTokens(chunks).toLocaleString()} tokens)`
      )
    )

    printDiffBanner({
      projectName: basename(projectRoot),
      headBranch,
      baseBranch: base,
      changedCount: changedFiles.length,
      additions,
      deletions,
    })

    const diffContext: DiffContext = {
      baseBranch: base,
      headBranch,
      changedFiles,
    }

    const context: AgentContext = {
      projectLanguages: await detectLanguages(projectRoot, scope),
      totalFiles: manifests.length,
      totalChunks: chunks.length,
      mode: 'standard',
      diffContext,
    }

    const agentCount = config.swarm.agentCount
    let completedAgents = 0

    const progressSpinner = ora('  Starting analysis...').start()

    const swarmResult = await runSwarm(chunks, context, {
      onAgentStart: (name: AgentName): void => {
        progressSpinner.text = `  [${completedAgents}/${agentCount}] ${name} agent analyzing...`
      },
      onAgentComplete: (
        name: AgentName,
        findings: number,
        durationMs: number
      ): void => {
        completedAgents++
        progressSpinner.text = `  [${completedAgents}/${agentCount}] ${name} complete (${findings} findings, ${(durationMs / 1000).toFixed(1)}s)`
      },
      onSynthesisStart: (): void => {
        progressSpinner.text = '  Synthesizing cross-agent findings...'
      },
      onSynthesisComplete: (durationMs: number): void => {
        progressSpinner.text = `  Synthesis complete (${(durationMs / 1000).toFixed(1)}s)`
      },
      timeoutMs: config.swarm.timeoutMs,
    })

    progressSpinner.succeed(
      `  Analysis complete — ${swarmResult.findings.length} findings in ${(swarmResult.durationMs / 1000).toFixed(1)}s`
    )

    const historyPath = join(projectRoot, config.score.historyFile)
    const baseScore = await getBaseScore(base, historyPath, projectRoot)

    const scoreResult = calculateScore(
      swarmResult.findings,
      swarmResult.crossAgentFindings,
      baseScore
    )

    appendEntry(historyPath, {
      timestamp: new Date().toISOString(),
      runId: swarmResult.runId,
      score: scoreResult.score,
      breakdown: scoreResult.breakdown,
      delta: scoreResult.delta,
    })

    const findingDiff = compareFindings(
      swarmResult.findings,
      [],
      changedFiles
    )

    const rankedIntroduced = rankIntroducedFindings(findingDiff.introduced)
    findingDiff.introduced = rankedIntroduced

    const hasCriticalIntroduced = rankedIntroduced.some(
      (f) => f.severity === 'critical'
    )

    printDiffSummary({
      score: scoreResult,
      findingDiff,
      changedFiles,
      baseBranch: base,
      headBranch,
      hasCriticalIntroduced,
      durationMs: swarmResult.durationMs,
    })

    const outputDir = join(projectRoot, '.palade/reports')
    if (!existsSync(outputDir)) mkdirSync(outputDir, { recursive: true })

    const dateStr = new Date().toISOString().slice(0, 10)
    const branchSlug = headBranch.replace(/\//g, '-')
    const reportName = `diff-${dateStr}-${branchSlug}`

    const reporterCtx = {
      score: scoreResult,
      swarm: swarmResult,
      synthesis: swarmResult.synthesis,
      findings: swarmResult.findings,
      crossAgentFindings: swarmResult.crossAgentFindings,
      history: readHistory(historyPath),
      config: {
        projectName: basename(projectRoot),
        runTimestamp: new Date().toISOString(),
      },
    }

    const formats = config.output.formats

    if (formats.includes('json')) {
      const jsonPath = join(outputDir, `${reportName}.json`)
      reportJson(reporterCtx, jsonPath)
      console.log(theme.success(`  JSON: ${jsonPath}`))
    }

    if (formats.includes('html')) {
      const htmlPath = join(outputDir, `${reportName}.html`)
      writeHtmlReport(reporterCtx, htmlPath)
      console.log(theme.success(`  HTML: ${htmlPath}`))
      if (config.output.openBrowser) {
        startLocalServer(htmlPath, config.output.port)
      }
    }

    if (formats.includes('md')) {
      const mdPath = join(outputDir, `${reportName}.md`)
      reportMarkdown(reporterCtx, mdPath)
      console.log(theme.success(`  Markdown: ${mdPath}`))
    }

    if (opts.ci && hasCriticalIntroduced) {
      console.error(
        theme.error('\n  ✗ Critical findings introduced. Blocking.')
      )
      process.exit(1)
    }
  } catch (err) {
    console.error(
      theme.error(`\nDiff review failed: ${(err as Error).message}`)
    )
    if ((err as Error).stack && process.env.DEBUG) {
      console.error(chalk.gray((err as Error).stack))
    }
    process.exit(1)
  }
}
